package WebDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JSExeDriver {
static WebDriver driver;
public static void main(String args[]) throws InterruptedException {
	
//chrome
System.setProperty("webdriver.chrome.driver","D:\\BDD\\chromedriver_win32\\chromedriver.exe");
driver=new ChromeDriver();
//loading page
JavascriptExecutor js = (JavascriptExecutor)driver;		
driver.get("file:///D:/Users/NEHASIN/Desktop/login.html");

//title
String title=driver.getTitle();
if(title.contentEquals("")) System.out.println("***************TITLE MATCHED*************");
else System.out.println("*****************TITLE DO NOT MATCHED*********************");

//valid login

driver.findElement(By.name("userName")).sendKeys("capgemini");Thread.sleep(1000);
driver.findElement(By.name("userPwd")).sendKeys("capg1234");Thread.sleep(1000);
WebElement button=driver.findElement(By.className("btn"));
js.executeScript("arguments[0].click()",button);
driver.navigate().to("file:///D:/Users/NEHASIN/Desktop/hotelbooking.html");
//driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
Thread.sleep(1000);
driver.navigate().back();
js.executeScript("history.go(0)");

//wrong credentials

driver.findElement(By.name("userName")).sendKeys("capgem");Thread.sleep(1000);
driver.findElement(By.name("userPwd")).sendKeys("capg");Thread.sleep(1000);
WebElement button1=driver.findElement(By.className("btn"));
js.executeScript("arguments[0].click()",button1);
callAlert();
js.executeScript("history.go(0)");


//no UserName

driver.findElement(By.name("userName")).sendKeys("");Thread.sleep(1000);
driver.findElement(By.name("userPwd")).sendKeys("capg1234");Thread.sleep(1000);
WebElement button2=driver.findElement(By.className("btn"));
js.executeScript("arguments[0].click()",button2);
String userAlert=driver.findElement(By.id("userErrMsg")).getText();
Thread.sleep(1000);
System.out.println("**************"+ userAlert);
js.executeScript("history.go(0)");

//no password

driver.findElement(By.name("userName")).sendKeys("capgemini");Thread.sleep(1000);
driver.findElement(By.name("userPwd")).sendKeys("");Thread.sleep(1000);
WebElement button3=driver.findElement(By.className("btn"));
js.executeScript("arguments[0].click()",button3);
String pwdAlert=driver.findElement(By.id("pwdErrMsg")).getText();
Thread.sleep(1000);
System.out.println("**************"+ pwdAlert);
js.executeScript("history.go(0)");
generateAlert(driver,"wrong Credentials");

}
public static void generateAlert(WebDriver driver,String message)
{
	JavascriptExecutor js = (JavascriptExecutor)driver;		
	js.executeScript("alert('"+message+"')");
 
}
public static void callAlert()
{
	String alertMessage=driver.switchTo().alert().getText();
	System.out.println(alertMessage);
	driver.switchTo().alert().accept();
}
}
